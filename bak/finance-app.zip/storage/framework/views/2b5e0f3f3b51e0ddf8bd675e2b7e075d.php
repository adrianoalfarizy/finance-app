<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-lg">Dashboard</h2>
     <?php $__env->endSlot(); ?>

    <div class="p-4 space-y-4">
        <form class="flex gap-2" method="get" action="<?php echo e(route('dashboard')); ?>">
            <select name="account_id" class="w-full border rounded p-2">
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>" <?php if(optional($active)->id == $acc->id): echo 'selected'; endif; ?>><?php echo e($acc->name); ?> (<?php echo e(strtoupper($acc->type)); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="px-3 py-2 bg-blue-600 text-white rounded">Pilih</button>
        </form>

        <?php if($active): ?>
        <div class="grid grid-cols-3 gap-3 text-center">
            <div class="bg-white rounded-xl p-4 shadow">
                <div class="text-xs text-gray-500">Saldo</div>
                <div class="text-xl font-bold">Rp <?php echo e(number_format($stats['balance'],0,',','.')); ?></div>
            </div>
            <div class="bg-white rounded-xl p-4 shadow">
                <div class="text-xs text-gray-500">Pemasukan</div>
                <div class="text-lg font-semibold text-green-600">Rp <?php echo e(number_format($stats['income'],0,',','.')); ?></div>
            </div>
            <div class="bg-white rounded-xl p-4 shadow">
                <div class="text-xs text-gray-500">Pengeluaran</div>
                <div class="text-lg font-semibold text-red-600">Rp <?php echo e(number_format($stats['expense'],0,',','.')); ?></div>
            </div>
        </div>

        <div class="bg-white rounded-xl p-4 shadow">
            <div class="font-semibold mb-2">Transaksi Terbaru</div>
            <ul class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $stats['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="py-2 flex items-center justify-between">
                        <div>
                            <div class="text-sm"><?php echo e($t->description ?? '-'); ?></div>
                            <div class="text-xs text-gray-500"><?php echo e($t->transacted_at->format('d M Y H:i')); ?></div>
                        </div>
                        <div class="text-sm font-semibold <?php echo e($t->type==='income'?'text-green-600':'text-red-600'); ?>">
                            <?php echo e($t->type==='income' ? '+' : '-'); ?>Rp <?php echo e(number_format($t->amount,0,',','.')); ?>

                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="py-2 text-sm text-gray-500">Belum ada transaksi.</li>
                <?php endif; ?>
            </ul>
        </div>
        <?php else: ?>
        <div class="text-sm text-gray-500">Anda belum memiliki akses ke akun manapun.</div>
        <?php endif; ?>
    </div>

    
    <div class="fixed bottom-0 inset-x-0 bg-white border-t shadow-sm">
        <div class="grid grid-cols-4 text-center text-xs">
            <a href="<?php echo e(route('dashboard')); ?>" class="p-2 <?php echo e(request()->routeIs('dashboard') ? 'text-blue-600' : ''); ?>">Dashboard</a>
            <a href="<?php echo e(route('accounts.index')); ?>" class="p-2 <?php echo e(request()->routeIs('accounts.*') ? 'text-blue-600' : ''); ?>">Akun</a>
            <a href="<?php echo e(route('transactions.index')); ?>" class="p-2 <?php echo e(request()->routeIs('transactions.*') ? 'text-blue-600' : ''); ?>">Transaksi</a>
            <a href="<?php echo e(route('savings.index')); ?>" class="p-2 <?php echo e(request()->routeIs('savings.*') ? 'text-blue-600' : ''); ?>">Tabungan</a>
            <a href="<?php echo e(route('debts.index')); ?>" class="p-2 <?php echo e(request()->routeIs('debts.*') ? 'text-blue-600' : ''); ?>">Hutang</a>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Adriano\Documents\finance-app\resources\views/dashboard.blade.php ENDPATH**/ ?>