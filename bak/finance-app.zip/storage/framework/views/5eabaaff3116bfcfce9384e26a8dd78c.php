<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <h2 class="font-semibold text-lg">Akun</h2> <?php $__env->endSlot(); ?>
    <div class="p-4 space-y-4">
        <a href="<?php echo e(route('accounts.create')); ?>" class="px-3 py-2 bg-blue-600 text-white rounded">+ Tambah Akun</a>
        <div class="bg-white rounded-xl shadow divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-3 flex items-center justify-between">
                    <div>
                        <div class="font-semibold"><?php echo e($a->name); ?></div>
                        <div class="text-xs text-gray-500"><?php echo e(strtoupper($a->type)); ?> • Saldo: Rp <?php echo e(number_format($a->balance,0,',','.')); ?></div>
                    </div>
                    <div class="flex gap-2">
                        
                        <a href="<?php echo e(route('accounts.share.edit',$a)); ?>" class="text-xs px-2 py-1 border rounded">Share</a>
                        <a href="<?php echo e(route('accounts.edit',$a)); ?>" class="text-xs px-2 py-1 border rounded">Edit</a>
                        <form method="post" action="<?php echo e(route('accounts.destroy',$a)); ?>" onsubmit="return confirm('Hapus akun?');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-xs px-2 py-1 border rounded text-red-600">Hapus</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-3 text-sm text-gray-500">Belum ada akun.</div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Adriano\Documents\finance-app\resources\views/accounts/index.blade.php ENDPATH**/ ?>