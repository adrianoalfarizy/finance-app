<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-lg">Hutang</h2>
     <?php $__env->endSlot(); ?>

    <div class="p-4 space-y-4 pb-16">
        
        <form class="grid grid-cols-12 gap-2" method="get" action="<?php echo e(route('debts.index')); ?>">
            <select name="account_id" class="col-span-9 sm:col-span-10 border rounded-lg p-2 h-10 w-full">
                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <option value="<?php echo e($acc->id); ?>" <?php if(optional($active)->id == $acc->id): echo 'selected'; endif; ?>><?php echo e($acc->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option disabled>Belum ada akun bertipe Hutang</option>
                <?php endif; ?>
            </select>
            <button class="col-span-3 sm:col-span-2 px-3 h-10 bg-blue-600 text-white rounded-lg w-full">Pilih</button>
        </form>

        
        <?php if($accounts->isEmpty()): ?>
            <div class="text-sm text-gray-600">
                Anda belum memiliki akun bertipe <strong>Hutang</strong>.
                <a href="<?php echo e(route('accounts.create', ['type' => 'debt'])); ?>" class="text-blue-600 underline">+ Buat Akun
                    Hutang</a>
            </div>
        <?php endif; ?>


        <a href="<?php echo e(route('debts.create')); ?>" class="px-3 py-2 bg-blue-600 text-white rounded-lg block text-center">+
            Catat Hutang</a>

        <?php $__currentLoopData = $debts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-2xl shadow p-4 space-y-3 overflow-hidden">
                
                <div class="flex items-start justify-between gap-3">
                    <div class="min-w-0">
                        <div class="font-semibold truncate"><?php echo e($d->creditor_name); ?></div>
                        <div class="text-xs text-gray-500">Status: <?php echo e(strtoupper($d->status)); ?></div>
                    </div>
                    <div class="text-right text-sm shrink-0">
                        <div>Pokok: Rp <?php echo e(number_format($d->principal_amount, 0, ',', '.')); ?></div>
                        <div>Terbayar: Rp <?php echo e(number_format($d->paid_amount, 0, ',', '.')); ?></div>
                        <div>Sisa: <span class="font-semibold">Rp <?php echo e(number_format($d->remaining, 0, ',', '.')); ?></span>
                        </div>
                    </div>
                </div>

                
                <form method="post" action="<?php echo e(route('debts.payments.store', $d)); ?>"
                    class="grid grid-cols-1 md:grid-cols-5 gap-2">
                    <?php echo csrf_field(); ?>

                    
                    <select name="pay_account_id" class="border rounded-lg p-2 h-10 w-full md:col-span-2"
                        aria-label="Akun pembayaran">
                        <?php $__currentLoopData = $spendableAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>


                    
                    <input name="amount" type="text" step="0.01" min="0"
                        class="border rounded-lg p-2 h-10 w-full md:col-span-1 js-currency" placeholder="Jumlah angsuran"
                        aria-label="Jumlah angsuran">

                    
                    <input name="transacted_at" type="datetime-local"
                        class="border rounded-lg p-2 h-10 w-full md:col-span-2" value="<?php echo e(now()->format('Y-m-d\TH:i')); ?>"
                        aria-label="Tanggal transaksi">

                    
                    <input name="note" class="border rounded-lg p-2 h-10 w-full md:col-span-4" placeholder="Catatan"
                        aria-label="Catatan">

                    
                    <button class="px-3 h-10 bg-blue-600 text-white rounded-lg w-full md:col-span-1">
                        Catat Pembayaran
                    </button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Adriano\Documents\finance-app\resources\views/debts/index.blade.php ENDPATH**/ ?>