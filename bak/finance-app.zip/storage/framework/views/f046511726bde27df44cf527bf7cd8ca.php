<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <h2 class="font-semibold text-lg">Transaksi</h2> <?php $__env->endSlot(); ?>

    <div class="p-4 space-y-3">
        <form class="flex gap-2" method="get" action="<?php echo e(route('transactions.index')); ?>">
            <select name="account_id" class="w-full border rounded p-2">
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>" <?php if(optional($active)->id==$acc->id): echo 'selected'; endif; ?>><?php echo e($acc->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="px-3 py-2 bg-blue-600 text-white rounded">Pilih</button>
        </form>

        <a href="<?php echo e(route('transactions.create')); ?>" class="px-3 py-2 bg-blue-600 text-white rounded block text-center">+ Tambah</a>

        <div class="bg-white rounded-xl shadow divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-3 flex justify-between items-center">
                    <div>
                        <div class="text-sm"><?php echo e($t->description ?? '-'); ?></div>
                        <div class="text-xs text-gray-500"><?php echo e($t->transacted_at->format('d M Y H:i')); ?></div>
                    </div>
                    <div class="text-right">
                        <div class="text-sm font-semibold <?php echo e($t->type==='income'?'text-green-600':'text-red-600'); ?>">
                            <?php echo e($t->type==='income' ? '+' : '-'); ?>Rp <?php echo e(number_format($t->amount,0,',','.')); ?>

                        </div>
                        <form method="post" action="<?php echo e(route('transactions.destroy',$t)); ?>" onsubmit="return confirm('Hapus transaksi?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-xs text-red-600">Hapus</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-3 text-sm text-gray-500">Belum ada transaksi.</div>
            <?php endif; ?>
        </div>

        <div><?php echo e($transactions->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Adriano\Documents\finance-app\resources\views/transactions/index.blade.php ENDPATH**/ ?>